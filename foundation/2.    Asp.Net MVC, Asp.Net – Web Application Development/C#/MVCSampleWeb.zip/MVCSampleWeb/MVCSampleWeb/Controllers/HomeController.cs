﻿using MVCSampleWeb.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MVCSampleWeb.Controllers
{
    public class HomeController : Controller
    {
        IList<User> studentList = new List<User>() { 
                    new User(){ Name="Steve", Age = 21 },
                    new User(){Name="Bill", Age = 25 },
                    new User(){ Name="Ram", Age = 20 }

                };
        // GET: Student
      

        public ActionResult Index()
        {
            var model = new User()
            {
                Name = "Start",
                Age = 5
            };
            TempData["ModelName"] = model;
            Session["sampleID"] = 12;
            return RedirectToAction("index", "home", new { area = "Admin" });
        }

        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }

        public ActionResult Add()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Add(string sname,string spass)
        {
            if (ModelState.IsValid)
            { }
            return View();
        }
    }
}