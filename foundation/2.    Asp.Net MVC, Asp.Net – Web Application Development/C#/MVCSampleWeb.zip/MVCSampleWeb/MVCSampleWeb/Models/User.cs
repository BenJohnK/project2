﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace MVCSampleWeb.Models
{
    public class User
    {
        [Required(ErrorMessage = "This is a Required Field")]
        public string Name { get; set; }

        [Required(ErrorMessage = "This is a Required Field")]
        public int Age { get; set; }
    }
}