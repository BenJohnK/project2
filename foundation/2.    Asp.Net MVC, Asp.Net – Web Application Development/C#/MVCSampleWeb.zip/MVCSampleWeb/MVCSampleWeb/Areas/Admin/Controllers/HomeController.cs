﻿using MVCSampleWeb.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MVCSampleWeb.Areas.Admin.Controllers
{
    public class HomeController : Controller
    {
       
        // GET: Admin/Home
        public ActionResult Index()
        {
            var model = TempData["ModelName"];
            int ID = Int32.Parse(Session["sampleID"].ToString());
            IList<User> studentList = new List<User>() { 
                    new User(){ Name="Steve", Age = 21 },
                    new User(){Name="Bill", Age = 25 },
                    new User(){ Name="Ram", Age = 20 }

                };
            ViewData["students"] = studentList;
            return View();
        }
    }
}